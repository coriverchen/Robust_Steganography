# MINICER
Code for publication: Zeng Kai, Chen Kejiang, Zhang Wweiming, et al. Improving robust adaptive steganography via minimizing channel errors[J]. Signal Processing, 2022, 195: 108498.

Test_QMAS.m   is the core file.
input parameters: 
  cover_dir: cover file address
  stego_dir: stego file address
  payload: payload (bpnzac)
  cover_QF: QF of cover images
  attack_QF: QF of JPEG recompression
  
  Author:   zk
